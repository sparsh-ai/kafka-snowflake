use role accountadmin; 

create database if not exists charger;

create schema if not exists kafka_poc;

use schema charger.kafka_poc;

use warehouse compute_wh;

select * from SALES_DATA order by RECORD_METADATA:CreateTime desc

create or replace dynamic table sales_data_transformed lag ='1 minute'
warehouse = 'COMPUTE_WH' as
select
    RECORD_CONTENT:name name
    ,RECORD_CONTENT:transaction_date::date transaction_date
    ,dateadd('ms',RECORD_METADATA:CreateTime,'1970-01-01') timetamp
from SALES_DATA

select * from sales_data_transformed