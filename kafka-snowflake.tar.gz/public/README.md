# Setup Process

## Download and Install Kafka

https://kafka.apache.org/downloads

If setting up on Windows, there are some additional settings, follow here:

https://www.geeksforgeeks.org/how-to-install-and-run-apache-kafka-on-windows/

## Download Kafka Snowflake Connector JAR

1. Download from https://mvnrepository.com/artifact/com.snowflake/snowflake-kafka-connector/1.9.4
2. Add in the Kafka libs folder

## Install JRE

```sh
sudo apt install openjdk-19-jre-headless
```

## Generate Private and Public keys

```sh
openssl genrsa -out rsa_key.pem 2048
openssl rsa -in rsa_key.pem -pubout -out rsa_key.pub
```

## Update Config Properties

1. Update Standalone Config file
2. Update SF Connect Config file
    - Private key will go here

## Add public key in Snowflake

Run this in Snowflake

```sql
alter user sparsh set RSA_PUBLIC_KEY='<public key string>';
desc user sparsh;
```

## Start Kafka server and Create topic

```sh
bin/zookeeper-server-start.sh config/zookeeper.properties
bin/kafka-server-start.sh config/server.properties
bin/kafka-topics.sh --create --topic sales-data --bootstrap-server localhost:9092
bin/connect-standalone.sh config/connect-standalone.properties config/SF_connect.properties
```

## Generate data

Note: Used data-generator python script

Alternate:

`bin/kafka-console-producer.sh --topic sales-data --bootstrap-server localhost:9092`

On another terminal, verify that consumer is receiving the messages:

`bin/kafka-console-consumer.sh --topic sales-data --from-beginning --bootstrap-server localhost:9092`

To send json via shell producer, use simple json format:

```py
{"transaction_date": "2021-03-02", "name": "Katherina Mende", "gender": "M", "city": "Rochlitz", "email": "ludmila23@hotmail.de", "product_id": "64859422", "amount_spent": 91.66}
```

## References

- https://hevodata.com/learn/kafka-to-snowflake/